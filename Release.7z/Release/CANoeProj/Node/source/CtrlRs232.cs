using System;
using Vector.Tools;
using Vector.CANoe.Runtime;
using Vector.CANoe.Sockets;
using Vector.CANoe.Threading;
using Vector.Diagnostics;
using System.Runtime.InteropServices;

public class CtrlRs232 : MeasurementScript
{
    private static string winSheet = "Rs232Window";
    private Rs232OperationFromCSharp vvc_rs232 = new Rs232OperationFromCSharp("COM4", ReceiveData);

    //��Ŵ洢log��txt�ļ���·��(�������ļ����Ƽ����׺)
    private static string txt_file_path = "D:\\Users\\uidq0175\\vsproj\\DevelopCANoeFunctionFromCSharp\\CANoeProj\\File\\";

    //��������excel�ļ�·��(���ļ����Ƽ����׺)
    private static string excel_file_path = "D:\\Users\\uidq0175\\vsproj\\DevelopCANoeFunctionFromCSharp\\CANoeProj\\File\\test.xlsx"; 

    private static byte store_status = 0;

    private static byte count = 0;

    private Timer gTimer = null; 

    /// <summary>
    /// Called before measurement start to perform necessary initializations,
    /// e.g. to create objects. During measurement, few additional objects
    /// should be created to prevent garbage collection runs in time-critical
    /// simulations.
    /// </summary>
    public override void Initialize()
    {
        Output.WriteLine(ExcelOperationFromCSharp.excelObjOpen(excel_file_path).ToString(), winSheet);
        vvc_rs232.RunnableCtrl = 1;
    }
    
    /// <summary>Notification that the measurement starts.</summary>
    public override void Start()
    {
        vvc_rs232.ConnectCom();
        gTimer = new Timer(TimeSpan.FromSeconds(5), Timer1);
        gTimer.Start();
    }
    
    /// <summary>Notification that the measurement ends.</summary>
    public override void Stop()
    {
        TxtOperationFromCSharp.CloseFile();
        vvc_rs232.DisconnectCom();
        ExcelOperationFromCSharp.saveFile();
        ExcelOperationFromCSharp.excelObjClose();
    }
    
    /// <summary>
    /// Cleanup after the measurement. Complement to Initialize. This is not
    /// a "Dispose" method; your object should still be usable afterwards.
    /// </summary>
    public override void Shutdown()
    {
    
    }

    private void Timer1(object sender, ElapsedEventArgs e)
    {
        string fname = "file_";
        gTimer.Stop();
        if (count < 10)
        {
            NewFile(fname + count.ToString() + "_.txt", count+1);
            Output.WriteLine(fname + count.ToString() + "_.txt", winSheet);
            gTimer = new Timer(TimeSpan.FromSeconds(5), Timer2);
            gTimer.Start();
        }
        count++;
    }

    private void Timer2(object sender, ElapsedEventArgs e)
    {
        SaveFile();
        gTimer.Stop();
        gTimer = new Timer(TimeSpan.FromSeconds(5), Timer1);
        gTimer.Start();
    }

    //�����µ�txt�ļ����øú���
    private static void NewFile(string fpath, int row)
    {
        string fullpath = txt_file_path + fpath;
        TxtOperationFromCSharp.OpenFile(fullpath, 1);

        //д��excelָ���ĵ�Ԫ��λ��
        ExcelOperationFromCSharp.setCellValue(fullpath, row, 5);
        store_status = 1;
    }

    //����txt�ļ���д����øú���
    private static void SaveFile()
    {
        store_status = 0;
        TxtOperationFromCSharp.CloseFile();
    }

    private static void ReceiveData(string ReadLine)
    {
        if (store_status == 1)
        {
            TxtOperationFromCSharp.Write2Txt(ReadLine);
        }
        //Output.WriteLine(ReadLine, winSheet);
    }
}